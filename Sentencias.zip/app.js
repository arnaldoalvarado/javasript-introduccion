/***********
 * Sentencia if..else
 */
/*var nombre = 'Grover';
var edad = 63;

// edad < 12 es un niño.
// edad > 11, es < 18, es un adolescente.
// edad > 17, es < 60, es un adulto.
// edad > 60 es un anciano.

if (edad < 12){
    console.log(nombre + ' es un niño.');
} else if((edad > 11) && (edad < 18)){
    console.log(nombre + ' es un adoslescente.');
}else if((edad > 17) && (edad < 60)){
    console.log(nombre + ' es un adulto.');
} else {
    console.log(nombre + ' es un anciano.');
}
*/

/***********
 * Setencia Switch
 */

 /*var mes = 1;

 switch(mes){
     case 1:
         console.log('Enero');
         break;
     case 2:
        console.log('Febrero');
        break;
     case 3:
        console.log('Marzo');
        break;
     case 4:
        console.log('Abril');
        break;
     default:
         console.log('Mes no encontado.');
 }*/


/**
 * Sentencia For
 */

/*for(var i=5; i <= 25; i+=5){
    console.log(i);
}*/


/***********
 * Sentencia While, Do while
 */
/*var i = 0;
while(i >= 1){
    console.log(i);
    i--;
}
console.log(i);*/

/*********
 * Sentencia Do..While
 */

 var i = 11;
 do{
    console.log(i);
    //i++;
 }while(i <= 10);
 console.log(i);

